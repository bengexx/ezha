Coin Magi CPU miner GUI v0.1
----------------------------
http://www.coinmagi.org/files/m-cpuminer/

Make sure you have changed pool or solo mining parameters to your own; registration in the following Coin Magi mining pools:

https://pom.m-hash.com/
https://pow.magipool.info/
http://xmg.suprnova.cc/
https://xmg.maxminers.net/
http://xmgpool.cf/
https://www.suchpool.pw/xmg/
http://minerclaim.net/

For any questions, visit the bitcointalk.org Coin Magi ANN thread:

https://bitcointalk.org/index.php?topic=735170.0

Official website: http://www.coinmagi.org/

